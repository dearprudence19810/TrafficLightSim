﻿
TrafficLightSimulator

Developed with C# 2015
Visual Studio Community 2015

Either load this project in visual studio or 
go to bin\Debug and run TrafficLightSimulator

Set configurations parameters in App.Config. It will run better if the departures from would keep up with the arrivals at light.


The requirements didn't really match the output of I misunderstood something

Rules:

- lights can not both be green
- when light turns red a car may not start moving whether it just arrived or was waiting
- it takes 2 seconds for 1st car to get through an intersection on green

*** Questions about the logic of this project! ***

The timing doesn't really make sense. The delays can be changed in the Config

If a light turns green and it only stays green for 3 seconds and a car can not start for 2 seconds 
then only 1 car would be able to get through per cycle which does not make sense.

"green" in both directions for 3 seconds; then turn it "red" for one second 
then turn Weaver "green" for 3 seconds; and then red for one second.

Seems to conflict with this requirement:

When the light turns from red to green at any intersection, it takes the first car 2 seconds to start moving 
and cross the intersection. Subsequent cars take 1 second each.

because logically if only 3 seconds green and 2 seconds for 1st car, next car would have really 0 chance of making this light after waitting another second


Operations:

cars arrive at each intersection every second, 4 per second, 1 each

lights can both be red but not both green

Start: Snell Rd. green both directions 3 seconds  then Weaver green 3 seconds and red 1 second

subsequent cars take 1 second



