﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace TrafficLightSimulator
{
    public class Vehicle
    {
        private DateTime _arriveAtLightTime;

        public Vehicle()
        {
            _arriveAtLightTime = DateTime.Now;
        }

        public int SecondsAtLight()
        {
            TimeSpan ts = DateTime.Now.Subtract(_arriveAtLightTime);
            return ts.Seconds;
        }
    }
}
