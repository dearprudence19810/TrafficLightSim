﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NLog;
using NLog.Config;

namespace TrafficLightSimulator
{


    public class Road : IRoad, IDisposable
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public String Name { get; }
        public RoadDirectionEnum RoadDirection { get; }
        public ITrafficLight Light { get; set; }
        public WaitingVehicles[] WaitingQueue;

        public TrafficLightSimulator.LigthChangeHandler LightChange;

        private Thread departThread = null;

        public Road(String name, RoadDirectionEnum roadDirection, ITrafficLight lightService )
        {
            Name = name;
            RoadDirection = roadDirection;
            Light = lightService;
            LightChange = OnLightChanged;

            WaitingQueue = new WaitingVehicles[2];

            if (RoadDirection == RoadDirectionEnum.NorthSouth)
            {
                WaitingQueue[(int) NorthSouthEnum.North] = new WaitingVehicles();
                WaitingQueue[(int)NorthSouthEnum.South] = new WaitingVehicles();
            }
            else
            {
                WaitingQueue[(int)EastWestEnum.East] = new WaitingVehicles();
                WaitingQueue[(int)EastWestEnum.West] = new WaitingVehicles();
            }
        }

        public void ListenToLightChangeHandler(ILightController lightController )
        {
            lightController.AddLightChangeListener(LightChange);
        }

        protected virtual void OnLightChanged()
        {
            // Console.WriteLine("{0} Road Direction Light Changed to {1}" , this.Name, Light.LightState.ToString());

            // start dequeueing
            logger.Trace("In Road.OnLightChanged");

            if ( Light.LightState() == LightStateEnum.Green)
            {
                if (departThread == null)
                {
                    logger.Trace("Starting new thread to depart intersection");
                    departThread = new Thread(this.DepartLight);
                    departThread.Start();

                    logger.Trace("Delaying thread for green signal");
                    Thread.Sleep(Config.GreenLightCycle);
                }
            }
            else
            {
                if( departThread != null )
                {
                    departThread.Abort();
                    departThread = null;

                    logger.Trace("Delaying thread for switch delay");
                    Thread.Sleep(Config.SwitchDelay);
                }
            }

            logger.Trace("Out Road.OnLightChanged");
        }

        private void DepartLight()
        {
            // wait the inital 2 seconds
            logger.Trace("In Road.DepartLight");

            logger.Trace("Sleep for start up delay");
            EventWaitHandle h = new EventWaitHandle(false, EventResetMode.AutoReset);
            h.WaitOne(Config.StartUpDelay);

            // Thread.Sleep(Config.StartUpDelay);
            Thread.CurrentThread.Priority = ThreadPriority.AboveNormal;

            while( Light.LightState() == LightStateEnum.Green )
            {
                logger.Trace("Depart on road " + this.Name );

                if (RoadDirection == RoadDirectionEnum.NorthSouth)
                {
                    WaitingQueue[(int)NorthSouthEnum.North].DepartFromLight();
                    WaitingQueue[(int)NorthSouthEnum.South].DepartFromLight();
                }
                else
                {
                    WaitingQueue[(int)EastWestEnum.East].DepartFromLight();
                    WaitingQueue[(int)EastWestEnum.West].DepartFromLight();
                }

                //Console.WriteLine( this.Name + " departed intersection on " + LightStateEnum.Green );
                h = new EventWaitHandle(false, EventResetMode.AutoReset);
                h.WaitOne(Config.DepartDelay);
            }
        }

        public void ArriveAtIntersection()
        {
            //Console.WriteLine(this.Name + " arrived intersection on " + Light.LightState().ToString());
            WaitingQueue[0].ArriveAtLight();
            WaitingQueue[1].ArriveAtLight();
        }

        public int WaitingNorthOrEast()
        {
            return WaitingQueue[0].WaitingCount();
        }

        public int WaitingSoutOrWest()
        {
            return WaitingQueue[1].WaitingCount();
        }

        public void Dispose()
        {
            if (departThread != null)
            {
                departThread.Abort();
                departThread = null;
            }
        }
    }
}
