﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficLightSimulator
{
    public interface ITrafficLight
    {
        LightStateEnum LightState();
        void TurnGreen();
        void TurnRed();
    }
}
