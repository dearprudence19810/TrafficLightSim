﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using NLog;

namespace TrafficLightSimulator
{
    public class WaitingVehicles
    {
        private ConcurrentQueue<Vehicle> _lightQueue;

        public WaitingVehicles()
        {
            _lightQueue = new ConcurrentQueue<Vehicle>();
        }

        public int WaitingCount()
        {
            return _lightQueue.Count;
        }

        public bool IsClear()
        {
            return _lightQueue.IsEmpty;
        }

        public void ArriveAtLight()
        {
            _lightQueue.Enqueue(new Vehicle());
        }

        public void DepartFromLight()
        {
            Vehicle departing;

            _lightQueue.TryDequeue(out departing);
        }
    }
}
