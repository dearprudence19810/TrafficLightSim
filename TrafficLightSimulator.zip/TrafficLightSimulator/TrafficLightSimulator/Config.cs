﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace TrafficLightSimulator
{
    public class Config
    {
        private static int redLightCycle = 1000;
        private static int greenLightCycle = 3000;
        private static int startUpDelay = 2000;
        private static int arriveAtLightPace = 1000;
        private static int switchDelay = 1000;
        private static int departDelay = 1000;

        static Config()
        {
            try
            {
                redLightCycle = int.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("RedLightCycle"));
                greenLightCycle = int.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("GreenLightCycle"));
                startUpDelay = int.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("StartUpDelay"));
                arriveAtLightPace = int.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("ArriveAtLightPace"));
                switchDelay = int.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("SwitchDelay"));
                departDelay = int.Parse(System.Configuration.ConfigurationManager.AppSettings.Get("DepartDelay"));
            }
            catch (FormatException ex)
            {
                System.Console.WriteLine("Invalid app.config. Make sure parameters are correct");
                throw ex;
            }
        }

        public static int RedLightCycle
        {
            get
            {
                return redLightCycle;
            }
        }

        public static int GreenLightCycle
        {
            get
            {
                return greenLightCycle;
            }
        }


        public static int StartUpDelay
        {
            get
            {
                return startUpDelay;
            }
        }


        public static int ArriveAtLightPace
        {
            get
            {
                return arriveAtLightPace;
            }
        }


        public static int SwitchDelay
        {
            get
            {
                return switchDelay;
            }
        }


        public static int DepartDelay
        {
            get
            {
                return departDelay;
            }
        }

    }
}
