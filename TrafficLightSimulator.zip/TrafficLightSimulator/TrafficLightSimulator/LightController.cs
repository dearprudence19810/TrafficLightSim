﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NLog;
using NLog.Config;

namespace TrafficLightSimulator
{
    public delegate void LigthChangeHandler();

    public class LightController : IOnOffSwitch, IDisposable , ILightController
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        IRoad[] Roads;
        private bool KeepSimulatiing { get;  set; }

        private LigthChangeHandler lightChangeHandlers;
        
        public LightController( Road r1, Road r2 )
        {
            Roads = new Road[2];
            Roads[0] = r1;
            Roads[1] = r2;
            r1.ListenToLightChangeHandler(this);
            r2.ListenToLightChangeHandler(this);
        }

        public void Run()
        {
            logger.Trace("In LightController.Run");
            KeepSimulatiing = true;
            Roads[0].Light.TurnRed();
            Roads[1].Light.TurnRed();
            Thread.CurrentThread.Priority = ThreadPriority.AboveNormal;

            //while(KeepSimulatiing)
            //{
            //    for (int i = 0; i < 2; i++)
            //    {
            //        // cycle 3 seconds green, 1 second red
            //        Roads[i % 2].Light.TurnGreen();
            //        Roads[(i + 1) % 2].Light.TurnRed();
            //    }

            //    logger.Trace("Sending Light Change Notifications for red and green");
            //    // send notification
            //    ChangeLights();

            //    for (int i = 0; i < 2; i++)
            //    {
            //        // turn red 1 second before turning other green
            //        Roads[i % 2].Light.TurnRed();
            //        Roads[i % 2].Light.TurnRed();
            //    }

            //    logger.Trace("Sending Light Change Notifications for both red");
            //    ChangeLights();

            //}


            while (KeepSimulatiing)
            {
                Roads[0].Light.TurnGreen();
                Roads[1].Light.TurnRed();

                logger.Trace("Sending Light Change Notifications for red and green");
                ChangeLights();

                Roads[0].Light.TurnRed();
                Roads[1].Light.TurnRed();

                logger.Trace("Sending Light Change Notifications for both red");
                ChangeLights();

                Roads[1].Light.TurnGreen();
                Roads[0].Light.TurnRed();

                logger.Trace("Sending Light Change Notifications for red and green");
                ChangeLights();

                Roads[1].Light.TurnRed();
                Roads[0].Light.TurnRed();

                logger.Trace("Sending Light Change Notifications for both red");
                ChangeLights();

            }

            logger.Trace("Out LightController.Run");
        }

        public void AddLightChangeListener(LigthChangeHandler handler )
        {
            lightChangeHandlers += handler;
        }

        public void ChangeLights()
        {
            if(lightChangeHandlers != null )
            {
                logger.Trace("Calling LightChangeHandlers");
                lightChangeHandlers();
            }
        }

        public void TurnOn()
        {
            KeepSimulatiing = true;
        }

        public void TurnOff()
        {
            KeepSimulatiing = false;
        }

        public void Dispose()
        {
            Roads[0].Dispose();
            Roads[1].Dispose();
        }
    }
}
