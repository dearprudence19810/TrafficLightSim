﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace TrafficLightSimulator
{
    public class TrafficLight : ITrafficLight
    {
        private LightStateEnum _state = LightStateEnum.Red;

        public LightStateEnum LightState()
        { 
            return _state;
        }

        public TrafficLight()
        {
        }

        public void TurnGreen()
        {
            _state = LightStateEnum.Green;
        }

        public void TurnRed()
        {
            _state = LightStateEnum.Red;
        }


    }
}
