﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace TrafficLightSimulator
{
    public enum RoadDirectionEnum
    {
        NorthSouth, EastWest
    }

    public enum NorthSouthEnum
    {
        North, South
    }

    public enum EastWestEnum
    {
        East, West
    }
}
