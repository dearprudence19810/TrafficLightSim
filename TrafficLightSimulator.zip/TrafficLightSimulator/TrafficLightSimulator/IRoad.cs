﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficLightSimulator
{
    public interface IRoad
    {
        void ListenToLightChangeHandler(ILightController lightController);
        void ArriveAtIntersection();
        int WaitingNorthOrEast();
        int WaitingSoutOrWest();
        ITrafficLight Light { get; set; }
        void Dispose();
    }
}
