﻿using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NLog;
using NLog.Config;

namespace TrafficLightSimulator
{
    public class TrafficSim
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public IRoad Snell;
        public IRoad Weaver;
        public ITrafficLight SnellLight;
        public ITrafficLight WeaverLight;

        public bool StopSimulation = false;
        ILightController lightController;

        static void Main(string[] args)
        {
            TrafficSim p = new TrafficSim();
            p.Init();
            p.Start();

        }

        void Init()
        {
            logger.Trace("In TrafficSim.Init");

            var kernel = new StandardKernel();
            kernel.Load(Assembly.GetExecutingAssembly());
            ITrafficLight SnellLight = kernel.Get<ITrafficLight>();
            ITrafficLight WeaverLight = kernel.Get<ITrafficLight>();

            var p1 = new Ninject.Parameters.ConstructorArgument("name", "Snell");
            var p2 = new Ninject.Parameters.ConstructorArgument("roadDirection", RoadDirectionEnum.NorthSouth);
            var p3 = new Ninject.Parameters.ConstructorArgument("lightService", SnellLight);
            Snell = kernel.Get<IRoad>(p1, p2, p3 );

            p1 = new Ninject.Parameters.ConstructorArgument("name", "Weaver");
            p2 = new Ninject.Parameters.ConstructorArgument("roadDirection", RoadDirectionEnum.EastWest);
            p3 = new Ninject.Parameters.ConstructorArgument("lightService", WeaverLight);
            Weaver = kernel.Get<IRoad>(p1, p2, p3);

            p1 = new Ninject.Parameters.ConstructorArgument("r1", Snell);
            p2 = new Ninject.Parameters.ConstructorArgument("r2", Weaver);
            lightController = kernel.Get<ILightController>(p1, p2 );

            Snell.ListenToLightChangeHandler(lightController);
            Weaver.ListenToLightChangeHandler(lightController);

            logger.Trace("Out TrafficSim.Init");
        }



        void Start()
        {
            logger.Trace("In TrafficSim.Start");
            System.Console.WriteLine("\nPress any key to quit\n");

            this.StopSimulation = false;
            int seconds = 0;

            logger.Trace("Starting LightController Thread");
            Thread t = new Thread(lightController.Run);
            t.Start();

            while ( ! this.StopSimulation )
            {
                // cars arrive into intersection one per second no matter light state
                logger.Trace("Arrive 1 car each at all interesections");

                Snell.ArriveAtIntersection();
                Weaver.ArriveAtIntersection();

                // main thread sleep 1 second
                logger.Trace("Main thread sleeping");

                EventWaitHandle h = new EventWaitHandle(false, EventResetMode.AutoReset);
                h.WaitOne(Config.ArriveAtLightPace);
                // Thread.Sleep(Config.ArriveAtLightPace);
                logger.Trace("Main thread awake");

                System.Console.WriteLine("{0}: N = {1}; S = {2}; E = {3}; W = {4}", seconds, Snell.WaitingNorthOrEast(), Snell.WaitingSoutOrWest(), Weaver.WaitingNorthOrEast(), Weaver.WaitingSoutOrWest());
                seconds++;

                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo info = Console.ReadKey();
                    lightController.TurnOff();
                    this.StopSimulation = true;
                }
            }

            lightController.Dispose();

            Console.WriteLine("\nType ENTER to quite...");
            Console.ReadKey();
            logger.Trace("Out TrafficSim.Start");
        }
    }
}
